import torch
import torch.nn as nn

class AnomalyDetector(nn.Module):
    """Deep autoencoder for high-throughput anomaly classification."""
    def __init__(self, input_dim=6, latent_dim=2):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 16),
            nn.GELU(),
            nn.Linear(16, latent_dim)
        )
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, 16),
            nn.GELU(),
            nn.Linear(16, input_dim)
        )

    def forward(self, x):
        z = self.encoder(x)
        return self.decoder(z)

if __name__ == '__main__':
    model = AnomalyDetector()
    print("Model initialized for Stage 1 evaluation.")
