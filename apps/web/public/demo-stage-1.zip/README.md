# Stage 1: Neural Anomaly Extraction & Data Decryption

Welcome to the **EventPlatform AI Club Contest Arena**.

### Objective
Inspect the accompanying files to deduce the anomaly boundary:
- Examine `sensor_metrics.csv` for cluster variances.
- Verify model configuration in `model_architecture.py`.
- Obtain the authorized AI system prompt from `ai_prompt.txt`.

### Anomaly Matrix
| Metric | Baseline | Observed Deviation | Status |
| :--- | :--- | :--- | :--- |
| Cluster Alpha | 1.024 | +0.042 ms | CRITICAL |
| Cluster Beta | 0.985 | -0.012 ms | NOMINAL |
| Cluster Gamma | 1.150 | +0.284 ms | ELEVATED |

---

### 🔑 Next Stage Decryption Key Clue
To clear this stage and unlock **Stage 2**, you must deduce the password of the Stage 2 archive.
> **Clue:** Combine the contest network keyword `cyber` with the current event year `2026` (i.e. `cyber2026`).
Click the **"Unlock Next Stage"** button above, enter this password, and unlock the next archive!
