Case study pool bundle — 10 archives
Generated: 2026-10-25T04:13:56.598Z

chakravyuh_case_study_01 → pool/chakravyuh_case_study_01/Chakravyuh_Case_Study_01.zip (36460 bytes)
chakravyuh_case_study_02 → pool/chakravyuh_case_study_02/case-study-archive.zip (58156 bytes)
case_study_03_helix_grid → pool/case_study_03_helix_grid/Case_Study_03_Helix_Grid.zip (14877 bytes)
case_study_04_mumbai_mint → pool/case_study_04_mumbai_mint/Case_Study_04_Mumbai_Mint.zip (12864 bytes)
case_study_05_packet_forge → pool/case_study_05_packet_forge/Case_Study_05_Packet_Forge.zip (12908 bytes)
case_study_06_satellite_kite → pool/case_study_06_satellite_kite/Case_Study_06_Satellite_Kite.zip (12839 bytes)
case_study_07_biolab_delta → pool/case_study_07_biolab_delta/Case_Study_07_BioLab_Delta.zip (12351 bytes)
case_study_08_tradewind → pool/case_study_08_tradewind/Case_Study_08_TradeWind.zip (13163 bytes)
case_study_09_cloudcastle → pool/case_study_09_cloudcastle/Case_Study_09_CloudCastle.zip (13199 bytes)
case_study_10_ridge_protocol → pool/case_study_10_ridge_protocol/Case_Study_10_Ridge_Protocol.zip (13010 bytes)

Upload individual files via Admin → Challenge Stages → pool, or use upload-case-study-pool.mjs.