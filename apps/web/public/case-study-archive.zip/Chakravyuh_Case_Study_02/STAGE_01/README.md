# STAGE 01: The Alarm Before the Alarm

## Story so far
Saturday, 20:02 IST. Meera Iyer is halfway through a cold samosa when her pager lights up
like a Diwali string. In `#inc-dhamaka-war-room`, Arjun types one line:
*"Declare it. Not a theory. A severity."*

Zoya pastes a wall of support tickets. Some say the cashback came twice. Some say the
payment is stuck. Some are the same customer, shouting three times. Six alerts have fired,
and one of them is about a bank partner having a rough night.

## Learn first
Incident triage with SLOs and severity matrices: counting distinct impact (not repeated
reports), separating core from non-core journeys, and why alert time is not impact time.

Open `AI_TUTOR_PROMPT.txt`, paste it into an AI tool, and spend a few minutes learning
the concept. The prompt deliberately asks the AI not to solve this incident.

## Investigate
Apply `evidence/severity_matrix.md` to the evidence. Decide the severity, the journey that
*drives* that severity, and the first minute of that journey's qualifying SLO breach run.
Alerts are not the SLO series; check which one the matrix uses.

PASSWORD: severity label, hyphen, driving journey in uppercase, hyphen, UTC time as HHMM of
the first minute of that journey's qualifying breach run (as defined in the matrix).
Example format: SEV3-PROFILE-0915

## Add to your incident report
Impact statement, severity rationale with the exact rule applied, distinct-customer count
method, incident start estimate (and why it is not the first alert), owner, open questions.

## Team rule
AI may explain concepts and challenge your reasoning. Your team must cite the exact
evidence used, perform key calculations, and be able to defend every conclusion.
