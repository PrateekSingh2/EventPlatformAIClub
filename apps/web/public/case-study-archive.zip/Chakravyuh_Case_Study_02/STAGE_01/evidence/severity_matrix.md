# SetuPay severity matrix (v3)

Core journeys: PAYMENT, PAYOUT
Non-core journeys: CASHBACK, BALANCE

A **qualifying breach run** is 3 or more consecutive one-minute samples that are strictly
below the journey's SLO target in `slo_targets.txt`. A single-minute dip does not count.
The run starts at the first minute of those consecutive samples.

- **SEV1** if either:
  (a) a core journey is below 85% success for a qualifying run, OR
  (b) a money-correctness defect (a customer received or lost funds incorrectly) is
      **verified in the ledger** for 25 or more DISTINCT customers, counting only tickets
      received 14:30:00 to 14:44:59 UTC inclusive.
- **SEV2** if not SEV1 and a core journey has a qualifying breach run of its SLO target.
- **SEV3** if not SEV1/SEV2 and only non-core journeys have a qualifying breach run.

The *driving journey* is the journey whose condition produced the severity.
