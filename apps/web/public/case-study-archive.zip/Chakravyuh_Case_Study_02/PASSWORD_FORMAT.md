# Password format — Chakravyuh Case Study 02

# Unlock password format

| Rule | Requirement |
|------|-------------|
| Case | **UPPERCASE** unless a stage README says otherwise |
| Characters | Letters, digits, hyphen `-` only — **no spaces** |
| Arena | Type the derived token exactly in the contest unlock field |
| Source | Derive from evidence in the **current** stage folder README |

Each `STAGE_XX/README.md` includes a **PASSWORD** or **Unlock** section with a format template.
Replace placeholders with values from that stage's evidence — example lines show **shape only**.


## Stage 01 → `STAGE_02.zip`

```
SEV<N>-<JOURNEY>-<HHMM>
```

- N = severity level digit from matrix
- JOURNEY = driving journey uppercase
- HHMM = first minute of qualifying SLO breach (UTC)

Example shape only: `SEV3-PROFILE-0915`

## Stages 02–12

After each decrypt, open that stage's `README.md` for the next `STAGE_XX.zip` format template.
Bonus stages (if present) follow the same pattern.
