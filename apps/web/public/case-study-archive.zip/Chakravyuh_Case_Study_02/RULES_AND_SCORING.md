# Rules and scoring guide

## Rules
1. Do not brute-force, crack, patch, or bypass archive passwords.
2. AI and web learning are allowed. SetuPay conclusions require evidence citations.
3. Keep an AI learning log: concept, question asked, useful learning, team verification.
4. Ask organizers only about unreadable/corrupt files, not whether a hypothesis is right.
5. Blameless language only. Name system conditions and missing defenses, not people.

## Scoring emphasis
- 15% accurate UTC timeline (with clock-skew handling stated explicitly)
- 30% evidence-backed causal chain
- 15% correct use of technical concepts
- 15% rejected hypotheses and uncertainty
- 10% money-movement impact and ledger integrity (confirmed vs estimated vs unknown)
- 10% safe remediation, validation, and rollback
- 5% clear AI learning log and communication

Unlock speed alone does not win; unsupported conclusions lose credit. A confident wrong
number loses more than an honest "unknown".
