# SetuPay incident report

Team name:
Members:

## 1. Executive summary
Impact, duration, affected journeys, money-movement status, and current status.

## 2. Evidence timeline
UTC time | event | source file | fact/estimate | clock-skew handling | confidence

## 3. Technical causal chain
Separate: latent condition → trigger → contributing conditions → amplification →
customer-visible effects. For every link, cite a file/line or data row and state the
mechanism. For every link, name one intervention or observation that would falsify it.

## 4. Hypothesis ledger
Hypothesis | supporting evidence | conflicting evidence | test/falsifier | status

## 5. Money-movement impact and ledger integrity
What was confirmed in the ledger, what is estimated, what is unknown. Units stated.

## 6. Root-cause statement
Explain why no single metric, component, or person fully explains the event.

## 7. Recovery and prevention
Action | mitigation/prevention | owner | risk | success metric | guardrail | rollback trigger

## 8. AI learning log
Stage | concept studied | question/prompt | useful learning | how team verified it

## 9. Optional bonus
Final recovery phrase:
