# CHAKRAVYUH: Case Study 02 — The Night the Ledger Lied

> *Saturday, 17 October 2026. 20:00 IST. SetuPay launches "Dhamaka Saturday": ₹50 cashback
> on your first three tea-stall, kirana and restaurant payments. Within ninety seconds,
> half of Pune is queueing at ChaiPlanet with a phone in hand. Within five minutes,
> a cashier says the money never arrived, a customer says the money arrived twice,
> and finance quietly asks a question nobody wants to hear:
> **"Why does the ledger say two different things?"**

You are SetuPay's incident response team. Evidence arrives in locked layers. Your goal is
not to name one broken box. Reconstruct what happened, explain *why every defense failed
at once*, work out what the money did, and propose a recovery that cannot make things worse.

## The cast (all fictional)
- **Meera Iyer** — payments on-call SRE. Tired. Right more often than she admits.
- **Arjun Rao** — payments lead and incident commander.
- **Zoya Khan** — support lead. Speaks for the customers.
- **Kabir Sethi** — engineer on the cashback team. Shipped a "perf tuning" change last week.
- **Nandita Bose** — finance controller. Reads ledgers the way others read novels.

## Format
- Team: 3–4 people
- Target time: 5 hours (this one is deliberately harder than a flash-sale warm-up)
- Required path: 10 stages; Bonus 11 and 12 are optional
- Begin in `STAGE_01`, derive its password, and open `STAGE_02.zip`.
- Each extracted ZIP contains one evidence folder and the next locked ZIP.
- Passwords are case-sensitive and contain no spaces. Each README states the exact
  normalization rule. Read it twice.

## Suggested roles
Rotate these roles each stage: evidence lead, AI learning lead, timeline keeper, skeptic.
The skeptic's only job: *"What else could explain this row?"*

## Warnings from the last responder
- Some evidence is decoy. Some of it is true and still irrelevant.
- Clocks lie. Units lie. Averages lie. Alert times lie most of all.
- A number that is not tied to a file and a row is a rumour.

## AI rule
Use AI to learn unfamiliar concepts and test your explanation, not as an answer vending
machine. Use each supplied tutor prompt. Record what you learned and independently verify
all incident claims against the supplied evidence.

## Fair-play extraction help
Use your normal archive app, 7-Zip, WinZip, Finder, or `unzip STAGE_02.zip`.
If a password fails, re-check the exact normalization rule in that stage. No web search
is needed for fictional SetuPay facts.

## Completion
Submit the incident report. A strong report distinguishes trigger, contributing
conditions, amplification, symptoms, money impact, and remediation. Optional bonuses
add a recovery phrase.
