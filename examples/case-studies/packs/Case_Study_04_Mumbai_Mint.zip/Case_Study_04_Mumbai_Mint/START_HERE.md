# Mumbai Mint — Weight of Trust

Coin batches fail QA; someone rounded the wrong way at scale.

## How this archive is structured

1. Read this file, then open `STAGE_01/`.
2. `STAGE_01/README.md` tells you how to **derive** the unlock for `STAGE_02.zip` (no ready-made unlock string is printed in evidence).
3. Each decrypted stage folder contains evidence plus the next locked `STAGE_XX.zip`.
4. Continue through **Stage 12** — the finale is inside `STAGE_12/`.
5. Read `PASSWORD_FORMAT.md` for a quick table of all unlock **format templates**.

## Password format (global)

- **UPPERCASE** letters, digits, hyphens only — no spaces.
- Each stage README includes an **Unlock `STAGE_XX.zip``** section with a ``` template ``` block.

## Story hook

The mint claims a single bad sensor. Finance sees ₹ at risk. Weigh the evidence literally — grams matter.

Good luck — trust the numbers, not rumors.
