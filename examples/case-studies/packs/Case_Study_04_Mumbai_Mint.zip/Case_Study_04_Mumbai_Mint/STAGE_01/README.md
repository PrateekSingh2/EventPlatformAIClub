# Stage 1 — Mint QA

Rows in `evidence/weights.csv` with `|error_mg| >= 12` are **defects**. Count them (**COUNT**). Earliest defect `batch` id's numeric part → **B** (integer).

```
MINT-<COUNT>-<B>
```

Example shape only — compute from CSV.

## Unlock `STAGE_02.zip`

**Password format (enter exactly in the arena):**

```
MINT-<COUNT>-<B>
```

- COUNT = defect rows (|error_mg| >= 12)
- B = numeric part of earliest defect batch id

*Example shapes in this pack are not your answer — compute from your evidence.*
