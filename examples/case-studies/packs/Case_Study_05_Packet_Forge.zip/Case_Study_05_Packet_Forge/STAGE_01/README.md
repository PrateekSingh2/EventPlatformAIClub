# Stage 1 — Frame hunt

`frames.hex`: each line `idx,crc8,valid`. Count lines with `valid=1` → **N**. `crc8` from the **last** valid line (bottom-up).

```
FRAME-<N>-<CRC8>
```

## Unlock `STAGE_02.zip`

**Password format (enter exactly in the arena):**

```
FRAME-<N>-<CRC8>
```

- N = count of valid=1 frames
- CRC8 = crc8 field of last valid frame (bottom-up)

*Example shapes in this pack are not your answer — compute from your evidence.*
