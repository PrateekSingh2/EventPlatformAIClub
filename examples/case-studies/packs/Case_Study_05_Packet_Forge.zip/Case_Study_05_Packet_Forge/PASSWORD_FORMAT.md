# Password format index — Packet Forge — Checksum Theater

# Unlock password format (read first)

Every locked `STAGE_XX.zip` needs a **derived key**. Type it exactly in the contest arena (or your unzip tool).

| Rule | Requirement |
|------|-------------|
| Case | **UPPERCASE** `A-Z` (convert before submit unless a stage says otherwise) |
| Characters | Letters, digits `0-9`, hyphen `-` only |
| Forbidden | Spaces, underscores, smart quotes, trailing punctuation |
| Shape | Each stage README gives a **format template** — replace placeholders with evidence values |
| Example lines | Show **shape only** (e.g. `SPIKE-3-1015`) — not the answer for your team |

## Where to look

1. Open the current stage folder (e.g. `STAGE_03/`).
2. Read `README.md` → section **Unlock `STAGE_XX.zip``**.
3. Use the ``` template ``` block — not the prose label "PASSWORD:" alone.

Stage-by-stage templates for this pack are also listed in `PASSWORD_FORMAT.md` at the archive root.


## Templates for this pack

| Completed stage | Unlocks | Format template |
|-----------------|---------|-----------------|
| After STAGE_01 | STAGE_02.zip | `FRAME-<N>-<CRC8>` |
| After STAGE_02 | STAGE_03.zip | `XOR-<HEX4>` |
| After STAGE_03 | STAGE_04.zip | `LEN-<HEX4>` |
| After STAGE_04 | STAGE_05.zip | `SEQ-<HEX4>` |
| After STAGE_05 | STAGE_06.zip | `MAC-DEAD` |
| After STAGE_06 | STAGE_07.zip | `CRC-55AA` |
| After STAGE_07 | STAGE_08.zip | `PORT-<HEX4>` |
| After STAGE_08 | STAGE_09.zip | `ACK-<SUM4>` |
| After STAGE_09 | STAGE_10.zip | `RST-<HEX2>` |
| After STAGE_10 | STAGE_11.zip | `PAY-<BYTES>` |
| After STAGE_11 | STAGE_12.zip | `FORGE-CLEAR` |

Derive values from evidence in the completed stage folder. Never copy example tokens from walkthroughs.
