# Stage 1

`passes.csv`: count rows where `elev_deg` >= 15 → **N**. First such row `time_utc` → **HHMM**.
```
TLE-<N>-<HHMM>
```

## Unlock `STAGE_02.zip`

**Password format (enter exactly in the arena):**

```
TLE-<N>-<HHMM>
```

- N = passes with elev_deg >= 15
- HHMM = UTC time of first qualifying pass (24h, no colon)

*Example shapes in this pack are not your answer — compute from your evidence.*
