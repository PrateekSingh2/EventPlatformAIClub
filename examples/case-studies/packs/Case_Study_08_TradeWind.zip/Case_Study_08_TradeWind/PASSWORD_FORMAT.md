# Password format index — TradeWind — Rounding Ripples

# Unlock password format (read first)

Every locked `STAGE_XX.zip` needs a **derived key**. Type it exactly in the contest arena (or your unzip tool).

| Rule | Requirement |
|------|-------------|
| Case | **UPPERCASE** `A-Z` (convert before submit unless a stage says otherwise) |
| Characters | Letters, digits `0-9`, hyphen `-` only |
| Forbidden | Spaces, underscores, smart quotes, trailing punctuation |
| Shape | Each stage README gives a **format template** — replace placeholders with evidence values |
| Example lines | Show **shape only** (e.g. `SPIKE-3-1015`) — not the answer for your team |

## Where to look

1. Open the current stage folder (e.g. `STAGE_03/`).
2. Read `README.md` → section **Unlock `STAGE_XX.zip``**.
3. Use the ``` template ``` block — not a stray label line without evidence.

Stage-by-stage templates for this pack are also listed in `PASSWORD_FORMAT.md` at the archive root.


## Templates for this pack

| Completed stage | Unlocks | Format template |
|-----------------|---------|-----------------|
| After STAGE_01 | STAGE_02.zip | `PAIR-<N>-<HHMM>` |
| After STAGE_02 | STAGE_03.zip | `PIP-<NNN>` |
| After STAGE_03 | STAGE_04.zip | `USD-<NNNN>` |
| After STAGE_04 | STAGE_05.zip | `EUR-<NNNN>` |
| After STAGE_05 | STAGE_06.zip | `SPOT-<NNNNN>` |
| After STAGE_06 | STAGE_07.zip | `SWAP-<NNN>` |
| After STAGE_07 | STAGE_08.zip | `LEG-B-<NN>` |
| After STAGE_08 | STAGE_09.zip | `FEE-<NNN>` |
| After STAGE_09 | STAGE_10.zip | `NET-ZERO` |
| After STAGE_10 | STAGE_11.zip | `BOOK-<NNN>` |
| After STAGE_11 | STAGE_12.zip | `<FINALE-CLEAR>` |

Derive values from evidence in the completed stage folder. Never copy example tokens from walkthroughs.
