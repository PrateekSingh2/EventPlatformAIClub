# Stage 1

Count FX **pairs** in `trades.csv` with `|notional_usd| >= 1000000` → **N**. Earliest `time` → **HHMM** UTC.
```
PAIR-<N>-<HHMM>
```

## Unlock `STAGE_02.zip`

**Password format (enter exactly in the arena):**

```
PAIR-<N>-<HHMM>
```

- N = trades with |notional_usd| >= 1_000_000
- HHMM = UTC time of earliest qualifying trade

*Example shapes in this pack are not your answer — compute from your evidence.*
