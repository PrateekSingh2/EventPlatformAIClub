# Stage 1

`trace.csv`: illegal transition = `to` not in allowed list for `from` (see `fsm.json`). Count illegal rows → **N**. First illegal `from` state name.
```
EDGE-<N>-<FROM>
```
FROM uppercase, first illegal only.

## Unlock `STAGE_02.zip`

**Password format (enter exactly in the arena):**

```
EDGE-<N>-<FROM>
```

- N = count of illegal FSM transitions
- FROM = from-state of first illegal row, uppercase

*Example shapes in this pack are not your answer — compute from your evidence.*
