# Stage 1

`plates.csv`: max `cfu` row → well id and value.
```
WELL-<well>-<cfu>
```
Hyphens as shown; well like D7.

## Unlock `STAGE_02.zip`

**Password format (enter exactly in the arena):**

```
WELL-<WELL>-<CFU>
```

- WELL = well id of max CFU row (e.g. D7)
- CFU = integer CFU count from that row

*Example shapes in this pack are not your answer — compute from your evidence.*
