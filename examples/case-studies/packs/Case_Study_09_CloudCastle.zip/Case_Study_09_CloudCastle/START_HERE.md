# CloudCastle — Log Chain

Immutable audit log with a missing hash link.

## How this archive is structured

1. Read this file, then open `STAGE_01/`.
2. `STAGE_01/README.md` tells you how to **derive** the unlock for `STAGE_02.zip` (no ready-made unlock string is printed in evidence).
3. Each decrypted stage folder contains evidence plus the next locked `STAGE_XX.zip`.
4. Continue through **Stage 12** — the finale is inside `STAGE_12/`.
5. Read `PASSWORD_FORMAT.md` for a quick table of all unlock **format templates**.

## Password format (global)

- **UPPERCASE** letters, digits, hyphens only — no spaces.
- Each stage README includes an **Unlock `STAGE_XX.zip``** section with a ``` template ``` block.

## Story hook

SRE pasted JSONL from three shards. One entry breaks the prev_hash chain — that minute matters.

Good luck — trust the numbers, not rumors.
