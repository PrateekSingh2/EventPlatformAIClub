# Stage 1

`audit.jsonl`: count lines where `prev_hash` != computed chain (treat first line as valid). Broken lines → **N**. First broken `ts` minute field **HHMM** from ISO timestamp.
```
HASH-<N>-<HHMM>
```

## Unlock `STAGE_02.zip`

**Password format (enter exactly in the arena):**

```
HASH-<N>-<HHMM>
```

- N = hash-chain break count
- HHMM = minute of first broken entry UTC

*Example shapes in this pack are not your answer — compute from your evidence.*
