# Helix Grid — Frequency Ghost

A regional SCADA export shows impossible harmonics before a blackout.

## How this archive is structured

1. Read this file, then open `STAGE_01/`.
2. `STAGE_01/README.md` tells you how to **derive** the password for `STAGE_02.zip` (nothing is labeled "the password is …").
3. Each decrypted stage folder contains evidence plus the next locked `STAGE_XX.zip`.
4. Continue through **Stage 12** — the finale is inside `STAGE_12/`.
5. Read `PASSWORD_FORMAT.md` for a quick table of all unlock **format templates**.

## Password format (global)

- **UPPERCASE** letters, digits, hyphens only — no spaces.
- Each stage README includes an **Unlock `STAGE_XX.zip``** section with a ``` template ``` block.

## Story hook

Night shift operator Priya left only CSVs and a broken Python filter. The grid controller insists "all nominal" — your job is to prove which bus actually oscillated first.

Good luck — trust the numbers, not rumors.
