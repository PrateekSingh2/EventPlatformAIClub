# broken — do not run blindly
TH = 0.040
# spikes = [r for r in rows if r['anomaly_score'] > TH]  # bug: should be >=
