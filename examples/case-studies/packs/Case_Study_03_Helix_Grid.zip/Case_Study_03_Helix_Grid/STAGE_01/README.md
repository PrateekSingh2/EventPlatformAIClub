# Stage 1 — Bus telemetry triage

Priya's export lists **anomaly_score** per sample. Treat any row with `anomaly_score >= 0.040` as a **spike**.

Also open `evidence/first_spike.log`: the **first** spike row's timestamp (UTC) gives **HHMM** (24h, no colon).

## Derive STAGE_02.zip password

```
SPIKE-<COUNT>-<HHMM>
```

- **COUNT** = number of spike rows in `telemetry.csv`
- **HHMM** = hour+minute from the first spike timestamp in the CSV (same order as file)

Example shape only: `SPIKE-3-1015` — compute yours from data.
